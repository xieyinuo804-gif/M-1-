package com.example.a_7_2501129;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class CustomGrid extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_grid);
    }
}